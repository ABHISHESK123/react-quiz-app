import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';

const app = express();
const PORT = 5000;

// ✅ MongoDB Atlas connection string
const MONGO_URL = 'mongodb+srv://Abhi9992:Abhi%409992@cluster0.hu6wkpp.mongodb.net/myquizdb?retryWrites=true&w=majority';

// ✅ Middlewares
app.use(cors());
app.use(express.json());

// ✅ Connect to MongoDB Atlas
mongoose.connect(MONGO_URL)
  .then(() => console.log('✅ MongoDB Connected'))
  .catch((err) => console.error('❌ MongoDB Connection Error:', err));

// ✅ Define Mongoose Schema & Model
const quizSchema = new mongoose.Schema({
  question: String,
  options: [String],
  answer: String,
});

const Quiz = mongoose.model('Quiz', quizSchema);

// ✅ POST API to save quiz question
app.post('/api/quizzes', async (req, res) => {
  try {
    const newQuiz = new Quiz(req.body);
    await newQuiz.save();
    res.status(201).json({ message: '✅ Quiz saved successfully!' });
  } catch (error) {
    res.status(500).json({ error: '❌ Failed to save quiz' });
  }
});

// ✅ GET API to fetch all quiz questions
app.get('/api/quizzes', async (req, res) => {
  try {
    const quizzes = await Quiz.find();
    res.json(quizzes);
  } catch (error) {
    res.status(500).json({ error: '❌ Failed to fetch quizzes' });
  }
});

// ✅ Start Server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
