export const jsQuizz = {
  questions: [
    {
      question:
        "Which of the following is used in React.js to increase performance?",
      choices: [
        "Virtual DOM",
        "Original DOM",
        "Both A and B",
        "None of the above",
      ],
      type: "MCQs",
      correctAnswer: "Virtual DOM",
    },
    {
      question: "What is ReactJS?",
      choices: [
        "Server-side framework",
        "User Interface framework",
        "both a and b",
        "None of the above",
      ],
      type: "MCQs",
      correctAnswer: "User Interface framework",
    },
    {
      question:
        "Identify the one which is used to pass data to components from outside",
      choices: ["Render with arguments", "setState", "PropTypes", "props"],
      type: "MCQs",
      correctAnswer: "props",
    },
    {
      question: "In which language is React.js written?",
      choices: ["Python", "Java", "C#", "JavaScript"],
      type: "MCQs",
      correctAnswer: "JavaScript",
    },
    {
      question: "What is Babel?",
      choices: [
        "JavaScript interpreter",
        "JavaScript transpiler",
        "JavaScript compiler",
        "None of the above",
      ],
      type: "MCQs",
      correctAnswer: "JavaScript compiler",
    },
    // ✅ NEW Computer Science Questions
    {
      question: "What does CPU stand for?",
      choices: [
        "Central Processing Unit",
        "Computer Processing Unit",
        "Control Program Unit",
        "Central Program Unit",
      ],
      type: "MCQs",
      correctAnswer: "Central Processing Unit",
    },
    {
      question: "Which data structure uses FIFO (First In First Out)?",
      choices: ["Stack", "Queue", "Tree", "Graph"],
      type: "MCQs",
      correctAnswer: "Queue",
    },
    {
      question: "What is the binary representation of decimal 10?",
      choices: ["1010", "1100", "1001", "1111"],
      type: "MCQs",
      correctAnswer: "1010",
    },
    {
      question: "Which of these is NOT a programming language?",
      choices: ["Python", "HTML", "Java", "C++"],
      type: "MCQs",
      correctAnswer: "HTML",
    },
    {
      question: "What is the full form of HTTP?",
      choices: [
        "Hyper Transfer Text Protocol",
        "HyperText Transfer Protocol",
        "HighText Transfer Protocol",
        "HyperText Translate Protocol",
      ],
      type: "MCQs",
      correctAnswer: "HyperText Transfer Protocol",
    },
  ],
};

export const resultInitalState = {
  score: 0,
  correctAnswers: 0,
  wrongAnswers: 0,
};
