import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';

const app = express();
const PORT = 5000;

// ✅ MongoDB Atlas connection
const MONGO_URL = 'mongodb+srv://Abhi9992:Abhi%409992@cluster0.hu6wkpp.mongodb.net/myquizdb?retryWrites=true&w=majority';

app.use(cors());
app.use(express.json());

// ✅ Connect to MongoDB Atlas
mongoose.connect(MONGO_URL)
  .then(() => console.log('✅ MongoDB Connected'))
  .catch((err) => console.error('❌ MongoDB Connection Error:', err));

// ✅ Define Schema and Model
const QuizSchema = new mongoose.Schema({
  question: String,
  options: [String],
  answer: String
});

const Quiz = mongoose.model('Quiz', QuizSchema);

// ✅ API Routes
app.get('/api/quizzes', async (req, res) => {
  const quizzes = await Quiz.find();
  res.json(quizzes);
});

app.post('/api/quizzes', async (req, res) => {
  const quiz = new Quiz(req.body);
  await quiz.save();
  res.json({ message: 'Quiz added!' });
});

// ✅ Start Server
app.listen(PORT, () => {
  console.log(`🚀 Backend running at http://localhost:${PORT}`);
});
